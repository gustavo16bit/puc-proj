import './App.css';
import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      senha: '',
      mensagem: ''
    };
    this.mudaEmail = this.mudaEmail.bind(this);
    this.mudaSenha = this.mudaSenha.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  mudaEmail(event) {
    let state = this.state;
    state.email = event.target.value;
    this.setState(state);
    console.log("muda email");
  }

  mudaSenha(event) {
    let state = this.state;
    state.senha = event.target.value;
    this.setState(state);
    console.log("muda senha");
  }

  handleSubmit(event) {
    const { email, senha } = this.state;
    if (email === 'eduardo.lino@pucpr.br' && senha === '123456') {
      this.setState({ mensagem: 'Acessado com sucesso!' });
    } else {
      this.setState({ mensagem: 'Usuário ou senha incorretos!' });
    }
  }

  render() {
    return (
      <div>
        <h1>Login</h1>
        <form onSubmit={this.handleSubmit}>
          <div>
            <input type="email" id="email" name="email" value={this.state.email} onChange={this.mudaEmail} />
          </div>
          <div>
            <input type="password" id="senha" name="senha" value={this.state.senha} onChange={this.mudaSenha} />
          </div>
          <button type='submit'>Acessar</button>
        </form>
        <label>{this.state.mensagem}</label>
      </div>
    );
  }
}

export default App;
